window.YTD.ni_devices.part0 = [ {
  "niDeviceResponse" : {
    "pushDevice" : {
      "deviceVersion" : "7.93.4-release.05",
      "deviceType" : "Twitter for Android",
      "token" : "fIikIKpUklU:APA91bEWQbUz56glXV_GgmfiIT6NhF-N3C2_eKhH0sEUbqdCLxr8a6Xl3iZ-ufoJPDDgg8RiF3qFsx-zPvsjYyGp9aBUmngIJ5jK9Z_eVR1YIGyKkcdtoIIV-rBtOcvAuwGvJP_0VzyH",
      "updatedDate" : "2019.12.02",
      "createdDate" : "2019.12.02"
    }
  }
} ]