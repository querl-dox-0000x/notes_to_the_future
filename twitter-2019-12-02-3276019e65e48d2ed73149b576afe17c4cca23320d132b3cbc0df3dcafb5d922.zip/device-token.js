window.YTD.device_token.part0 = [ {
  "deviceToken" : {
    "clientApplicationId" : "3033300",
    "token" : "07raEdm60uAPATWvzc2N7EM8sN76UmB3utIfS3tG",
    "createdAt" : "2019-12-02T14:27:08.504Z",
    "lastSeenAt" : "2019-12-02T14:27:08.506Z",
    "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
  }
}, {
  "deviceToken" : {
    "clientApplicationId" : "258901",
    "token" : "f5DseiiKhZoYbnS5Gg7Kmhu4oEllLRmTeMtuvXGo",
    "createdAt" : "2019-12-02T20:51:02.695Z",
    "lastSeenAt" : "2019-12-02T20:51:02.697Z",
    "clientApplicationName" : "Twitter for Android (Twitter, Inc.)"
  }
} ]