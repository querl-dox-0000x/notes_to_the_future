window.YTD.tweet.part0 = [ {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Whole Foods Market",
      "screen_name" : "WholeFoods",
      "indices" : [ "0", "11" ],
      "id_str" : "15131310",
      "id" : "15131310"
    } ],
    "urls" : [ {
      "url" : "https://t.co/Fo81h8eVpT",
      "expanded_url" : "https://querl.dox.gitlab.io/clarence-daniels-jr/book/notes_to_the_future/notes/#Whole_Foods",
      "display_url" : "querl.dox.gitlab.io/clarence-danie…",
      "indices" : [ "139", "162" ]
    } ]
  },
  "display_text_range" : [ "0", "162" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "1200821885862371330",
  "id_str" : "1201514575516045312",
  "in_reply_to_user_id" : "15131310",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1201514575516045312",
  "in_reply_to_status_id" : "1200821885862371330",
  "possibly_sensitive" : false,
  "created_at" : "Mon Dec 02 14:52:52 +0000 2019",
  "favorited" : false,
  "full_text" : "@WholeFoods \"Targeted Product Tampering\" is an acceptable practice at Whole Foods Market.  2 confirmed locations.\n\nWhat's in your locker?\n\nhttps://t.co/Fo81h8eVpT",
  "lang" : "en",
  "in_reply_to_screen_name" : "WholeFoods",
  "in_reply_to_user_id_str" : "15131310"
}, {
  "retweeted" : false,
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ {
      "name" : "Union County Sheriff",
      "screen_name" : "UnionCoSheriff",
      "indices" : [ "0", "15" ],
      "id_str" : "937061330",
      "id" : "937061330"
    } ],
    "urls" : [ {
      "url" : "https://t.co/BJDrXO6DkF",
      "expanded_url" : "https://querl.dox.gitlab.io/clarence-daniels-jr/book/notes_to_the_future/notes/#Murder_Attempt",
      "display_url" : "querl.dox.gitlab.io/clarence-danie…",
      "indices" : [ "100", "123" ]
    } ]
  },
  "display_text_range" : [ "0", "123" ],
  "favorite_count" : "0",
  "in_reply_to_status_id_str" : "1197249868126937088",
  "id_str" : "1201513735967383553",
  "in_reply_to_user_id" : "937061330",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1201513735967383553",
  "in_reply_to_status_id" : "1197249868126937088",
  "possibly_sensitive" : false,
  "created_at" : "Mon Dec 02 14:49:32 +0000 2019",
  "favorited" : false,
  "full_text" : "@UnionCoSheriff Staff at Union County Jail attempt murder and fail.\nPretend like it didn't happen.\n\nhttps://t.co/BJDrXO6DkF",
  "lang" : "en",
  "in_reply_to_screen_name" : "UnionCoSheriff",
  "in_reply_to_user_id_str" : "937061330"
} ]