window.YTD.account.part0 = [ {
  "account" : {
    "email" : "querl.dox.0000x@protonmail.com",
    "createdVia" : "oauth:3033300",
    "username" : "notes_to_future",
    "accountId" : "1201508054593871874",
    "createdAt" : "2019-12-02T14:27:08.377Z",
    "accountDisplayName" : "querl.dox.0000x"
  }
} ]