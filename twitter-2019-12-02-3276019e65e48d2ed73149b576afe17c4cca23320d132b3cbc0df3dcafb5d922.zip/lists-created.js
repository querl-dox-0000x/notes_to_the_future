window.YTD.lists_created.part0 = [ {
  "userListInfo" : {
    "urls" : [ ]
  }
} ]