window.YTD.profile.part0 = [ {
  "profile" : {
    "description" : {
      "bio" : "",
      "website" : "https://t.co/LdG13ksFPj",
      "location" : ""
    },
    "avatarMediaUrl" : "https://abs.twimg.com/sticky/default_profile_images/default_profile.png"
  }
} ]