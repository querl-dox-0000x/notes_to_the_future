window.YTD.screen_name_change.part0 = [ {
  "screenNameChange" : {
    "accountId" : "1201508054593871874",
    "screenNameChange" : {
      "changedAt" : "2019-12-02T14:29:35.000Z",
      "changedFrom" : "Querl0",
      "changedTo" : "querl_dox_0000x"
    }
  }
}, {
  "screenNameChange" : {
    "accountId" : "1201508054593871874",
    "screenNameChange" : {
      "changedAt" : "2019-12-02T14:32:34.000Z",
      "changedFrom" : "querl_dox_0000x",
      "changedTo" : "notes_to_future"
    }
  }
} ]