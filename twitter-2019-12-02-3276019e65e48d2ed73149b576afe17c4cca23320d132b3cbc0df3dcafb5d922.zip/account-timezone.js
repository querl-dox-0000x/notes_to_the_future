window.YTD.account_timezone.part0 = [ {
  "accountTimezone" : {
    "accountId" : "1201508054593871874"
  }
} ]